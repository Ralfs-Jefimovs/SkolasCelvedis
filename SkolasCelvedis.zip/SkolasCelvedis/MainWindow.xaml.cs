﻿using SharpVectors.Dom.Svg;
using SharpVectors.Renderers.Utils;
using SharpVectors.Renderers.Wpf;
using SharpVectors.Runtime;
using SkolasCelvedis.JsonHandle;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static SkolasCelvedis.Models;

namespace SkolasCelvedis
{
    public partial class MainWindow : Window
    {
        //DataFolder located in Project/bin/Debug/DataFolder
        private string dataFolder = "DataFolder";

        private Point _lastMouse;
        private bool _isDragging = false;

        private List<GeometryDrawing> _allGeometries = new List<GeometryDrawing>();
        private Dictionary<string, GeometryDrawing> _roomsById = new Dictionary<string, GeometryDrawing>();

        private GeometryDrawing _highlightedGeometry = null;
        private Brush _originalBrush = null;

        private string _currentFloor = "first_floor.svg";

        private JsonRepository<Floor> floors;
        private JsonRepository<Room> rooms;
        private JsonRepository<Employee> employees;
        private JsonRepository<Subject> subjects;
        private JsonRepository<EmployeeRoom> employeeRooms;
        private JsonRepository<EmployeeSubject> employeeSubjects;

        public MainWindow()
        {


            InitializeComponent();

            //Json Handling in main code
            string BasePath = AppDomain.CurrentDomain.BaseDirectory;
            dataFolder = System.IO.Path.Combine(BasePath, "JsonData");
            Directory.CreateDirectory(dataFolder);

            floors = new JsonRepository<Floor>(System.IO.Path.Combine(dataFolder, "floors.json"));
            rooms = new JsonRepository<Room>(System.IO.Path.Combine(dataFolder, "rooms.json"));
            employees = new JsonRepository<Employee>(System.IO.Path.Combine(dataFolder, "employees.json"));
            subjects = new JsonRepository<Subject>(System.IO.Path.Combine(dataFolder, "subjects.json"));
            employeeRooms = new JsonRepository<EmployeeRoom>(System.IO.Path.Combine(dataFolder, "employeeRooms.json"));
            employeeSubjects = new JsonRepository<EmployeeSubject>(System.IO.Path.Combine(dataFolder, "employeeSubjects.json"));

            Loaded += MainWindow_Loaded;
            Quit_Map();

        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {

            var drawing = FloorSvgCanvas.Drawings as DrawingGroup;
            ReloadSvgAndExtract();
            if (drawing != null)
            {
                _allGeometries.Clear();
                _roomsById.Clear();
                ExtractGeometries(drawing);
            }
        }

        private void Map_MouseMove(object sender, MouseEventArgs e)
        {
            if (!_isDragging) return;

            Point current = e.GetPosition(TransformWrapper);

            MapTranslateTransform.X += current.X - _lastMouse.X;
            MapTranslateTransform.Y += current.Y - _lastMouse.Y;

            _lastMouse = current;
        }

        private void Map_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            _isDragging = true;
            _lastMouse = e.GetPosition(TransformWrapper);
            TransformWrapper.CaptureMouse();
        }

        private void Map_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            _isDragging = false;
            TransformWrapper.ReleaseMouseCapture();
            Point visualPoint = e.GetPosition(FloorSvgCanvas);
            Point svgPoint = visualPoint;

        }


        private void HighlightGeometry(GeometryDrawing geo)
        {
            if (_highlightedGeometry != null && _originalBrush != null)
                _highlightedGeometry.Brush = _originalBrush;

            _originalBrush = geo.Brush;
            _highlightedGeometry = geo;

            geo.Brush = new SolidColorBrush(Color.FromArgb(180, 255, 100, 100));

            FloorSvgCanvas.InvalidateVisual();
        }

        private void Map_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            double zoomFactor = e.Delta > 0 ? 1.1 : 0.9;

            Point mousePosition = e.GetPosition(TransformWrapper);

            double absoluteX = (mousePosition.X - MapTranslateTransform.X) / MapScaleTransform.ScaleX;
            double absoluteY = (mousePosition.Y - MapTranslateTransform.Y) / MapScaleTransform.ScaleY;

            MapScaleTransform.ScaleX *= zoomFactor;
            MapScaleTransform.ScaleY *= zoomFactor;

            MapTranslateTransform.X = mousePosition.X - absoluteX * MapScaleTransform.ScaleX;
            MapTranslateTransform.Y = mousePosition.Y - absoluteY * MapScaleTransform.ScaleY;
        }

        private void Quit_Map()
        {
            this.PreviewKeyDown += MainWindow_PreviewKeyDown;
            this.Focusable = true;
            this.Focus();
        }

        private void MainWindow_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Q)
            {
                Application.Current.Shutdown();
            }
        }

        private void FloorComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                MapScaleTransform.ScaleX = 1;
                MapScaleTransform.ScaleY = 1;
                MapTranslateTransform.X = 0;
                MapTranslateTransform.Y = 0;

                if (FloorComboBox.SelectedIndex == 0)
                {
                    _currentFloor = "first_floor.svg";
                    FloorSvgCanvas.Source = new Uri("/Floors/first_floor.svg", UriKind.Relative);
                }
                else if (FloorComboBox.SelectedIndex == 1)
                {
                    _currentFloor = "second_floor.svg";
                    FloorSvgCanvas.Source = new Uri("/Floors/second_floor.svg", UriKind.Relative);
                }
                else if (FloorComboBox.SelectedIndex == 2)
                {
                    _currentFloor = "third_floor.svg";
                    FloorSvgCanvas.Source = new Uri("/Floors/third_floor.svg", UriKind.Relative);
                }


                Dispatcher.InvokeAsync(() =>
                {
                    ReloadSvgAndExtract();
                    Return_ToPosition();
                }, System.Windows.Threading.DispatcherPriority.Loaded);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading floor: {ex.Message}");
            }
        }

        private void Return_ToPosition()
        {
            var drawing = FloorSvgCanvas.Drawings as DrawingGroup;
            if (drawing == null)
                return;

            Rect bounds = drawing.Bounds;

            double containerWidth = TransformWrapper.ActualWidth;
            double containerHeight = TransformWrapper.ActualHeight;

            if (containerWidth <= 0 || containerHeight <= 0)
                return;

            double scaleX = containerWidth / bounds.Width;
            double scaleY = containerHeight / bounds.Height;

            double scale = Math.Min(scaleX, scaleY);

            MapScaleTransform.ScaleX = scale;
            MapScaleTransform.ScaleY = scale;


            MapTranslateTransform.X =
                (containerWidth - bounds.Width * scale) / 2 - bounds.X * scale;

            MapTranslateTransform.Y =
                (containerHeight - bounds.Height * scale) / 2 - bounds.Y * scale;
        }

        private void ReturnToOriginButton_Click(object sender, RoutedEventArgs e)
        {
            FloorComboBox.SelectedIndex = 0;
        }

        private void ExtractGeometries(DrawingGroup drawingGroup)
        {
            foreach (var drawing in drawingGroup.Children)
            {
                if (drawing is GeometryDrawing geo)
                {
                    _allGeometries.Add(geo);

                    string id = SvgObject.GetId(geo);

                    if (!string.IsNullOrEmpty(id))
                    {
                        _roomsById[id] = geo;
                        System.Diagnostics.Debug.WriteLine($"Found geometry with ID: {id}");
                    }
                }
                else if (drawing is DrawingGroup childGroup)
                {
                    ExtractGeometries(childGroup);
                }

            }
        }

        private void SearchTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                string searchId = SearchTextBox.Text.Trim();

                if (_roomsById.TryGetValue(searchId, out var geo))
                {
                    HighlightGeometry(geo);
                }
                else if (string.IsNullOrEmpty(searchId))
                {
                    MessageBox.Show("Please enter a room ID to search.");
                }
                else
                {
                    MessageBox.Show($"Room with ID '{searchId}' not found.");
                }
            }
        }
        private void ReloadSvgAndExtract()
        {
            Dispatcher.InvokeAsync(() =>
            {
                var drawing = FloorSvgCanvas.Drawings as DrawingGroup;

                if (drawing != null)
                {
                    _allGeometries.Clear();
                    _roomsById.Clear();
                    _highlightedGeometry = null;
                    _originalBrush = null;

                    ExtractGeometries(drawing);

                    System.Diagnostics.Debug.WriteLine("Geometries extracted for new floor.");
                }

            }, System.Windows.Threading.DispatcherPriority.Background);
        }

        public void AddEmployeeClick(object sender, RoutedEventArgs e)
        {
            var addEmployeeWindow = new AddEmployee(employees);
            addEmployeeWindow.ShowDialog();
        }

        private void ViewEmployeeButton_Click(object sender, RoutedEventArgs e)
        {

        }
    }

}