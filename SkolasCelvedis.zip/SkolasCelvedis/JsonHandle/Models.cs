﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SkolasCelvedis
{
    public class Models
    {
        /// <summary>
        /// Every class in this is purely for the purpose
        /// of turning this into Json repository and storing it in a file.
        /// When the search function is used it uses the json file to find
        /// the necessary search.
        /// </summary>
        public class Floor
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public string SVGFile { get; set; }
        }

        public class Room
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public int FloorId { get; set; }
            public string Type { get; set; }
            public string SVGId { get; set; } 
        }

        public class Employee
        {
            public int Id { get; set; }
            public string First_Name {  get; set; }
            public string Last_Name { get; set; }
        }

        public class  Subject
        {
            public int Id { get; set; }
            public string name { get; set; }
        }

        public class EmployeeSubject
        {
            public int EmployeeId { get; set; }
            public int SubjectId { get; set; }
        }
        
        public class EmployeeRoom
        {
            public int EmployeeId { get; set; }
            public int RoomId { get; set; } = 0;
        }
    }
}
