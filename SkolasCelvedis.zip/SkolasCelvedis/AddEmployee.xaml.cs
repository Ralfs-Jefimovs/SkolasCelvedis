﻿using SkolasCelvedis.JsonHandle;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static SkolasCelvedis.Models;
using static SkolasCelvedis.AddEmployee;



namespace SkolasCelvedis
{

    public partial class AddEmployee : Window
    {
        private readonly JsonRepository<Employee> _employees;

        public AddEmployee(JsonRepository<Employee> employees)
        {
            InitializeComponent();
            _employees = employees;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            var employee = new Employee
            {
                Id = _employees.GetAll().Count + 1,
                First_Name = NameTextBox.Text,
                Last_Name = LastNameTextBox.Text

            };

            _employees.Add(employee);
            MessageBox.Show("Darbinieks saglabāts!");
            this.Close();

        }
    }
}
